<?php
/*
 * Project:	 	c2php
 * Packet:		c2php-server
 * File:		c2php.php
 * Created on:	Dec 11, 2007
 * Created by:	pat
 */
 
 static $iPORT = 6666;					// 1-1024 require root permission
 static $iPROTOCOL = SOL_TCP;			// SOL_UDP || SOL_TCP
 static $iIPVERSION = AF_INET;			// AF_INET6 || AF_INET
 static $strINTERFACE = "192.168.6.117";
 static $bDEBUG = TRUE;					// FALSE
 static $strFILENAME = "log.txt";		// Name of the log file
 static $iRCVTIMEO = 10;				// Seconds until server closed, if there is no connection
 static $iBytesToReceive = 512;			// Bytes to receive per connection

 // includes
 require_once("socketmgr.php");
 
 // starting the script
 echo("[+]Staring server...<br>");
 $start = new c2php;
 
 if($start->main_logic())
 {
 	echo("[+]Server successfully stoped.<br>");
 }
 else
 {
 	echo("[-]Server stoped with failures.<br>");
 }
 
 class c2php
 {
 	public function main_logic()
 	{
		$logic = new socketmgr();

		if($logic->sock_logic())
		{
			return TRUE;
		}
		
		return FALSE;
 	}
 }
?>
