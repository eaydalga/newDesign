<?php
/*
 * Project:	 	c2php
 * Packet:		c2php-server
 * File:		socketmgr.php
 * Created on:	Dec 12, 2007
 * Created by:	pat
 */

require_once("filemgr.php");

 class socketmgr
 {
	private $iSocket = 0;
	private $strBuffer = "";

	public function sock_logic()
	{
		$return = FALSE;

		$sock_logic = new socketmgr();

		//create
		if($sock_logic->create())
		{
			$return = TRUE;
		}
		else
		{
			return FALSE;
		}
/*
		//listen
		if($sock_logic->listen())
		{
			$return = TRUE;
		}
		else
		{
			return FALSE;
		}
*/
		//receive
		if($sock_logic->receive())
		{
			$return = TRUE;
		}
		else
		{
			return FALSE;
		}

		//close
		if($sock_logic->close())
		{
			$return = TRUE;
		}
		else
		{
			return FALSE;
		}

		return $return;
	}

	private function onFailure()
	{
		global $iSocket;
		global $strBuffer;
		global $bDEBUG;

		echo("[!]Running failure function. Cleaning up socket resources.<br>");

		@socket_shutdown($iSocket, 2);
		@socket_close($iSocket);
		
		unset($iSocket);
		unset($strBuffer);
		
		echo("[!]Socket successfully closed.<br>");

		return false;
	}

 	private function create()
 	{
		global $iIPVERSION;
		global $iPROTOCOL;
		global $iSocket;
		global $bDEBUG;
		global $iRCVTIMEO;
		global $iPORT;

		/* Check the port number */
		$temp = new socketmgr;
		if(!$temp->chkPortNr())
		{
			return FALSE;
		}
		
		/* Allow the script to hang around waiting for connections. */
		set_time_limit(0);

		if($iPROTOCOL == SOL_TCP)	// TCP
		{
			$iType = SOCK_STREAM;
		}
		else	// UDP
		{
			$iType = SOCK_DGRAM;
		}
		
		/* Create a socket */

/*		This method doesn't allow to connect to multiple interfaces
		if(!$iSocket = @socket_create($iIPVERSION, $iType, $iPROTOCOL))
		{
			echo("[-]Could not create socket.<br>");
			if($bDEBUG == TRUE) echo '<font color="red">-->'.socket_strerror(socket_last_error($iSocket)).'</font><br>';
			return FALSE;
		}
*/

		if(!$iSocket = @socket_create_listen($iPORT))
		{
				echo("[-]Could not create socket.<br>");
				if($bDEBUG == TRUE) echo '<font color="red">-->'.socket_strerror(socket_last_error($iSocket)).'</font><br>';
				return FALSE;
		}

		echo("[+]Socket successfully created.<br>");

		// Make socket reusable
		if(!socket_set_option($iSocket,SOL_SOCKET,SO_REUSEADDR,1) || !socket_set_option($iSocket, SOL_SOCKET, SO_KEEPALIVE, 1) || !socket_set_option($iSocket, SOL_SOCKET, SO_SNDTIMEO, array("sec"=>10, "usec"=>0)) || !socket_set_option($iSocket, SOL_SOCKET, SO_LINGER, array("l_onoff"=>1, "l_linger"=>0)) || !socket_set_option($iSocket, SOL_SOCKET, SO_RCVTIMEO, array("sec"=>$iRCVTIMEO, "usec"=>0)))
		{
			echo("[-]Could not socket option.<br>");
			if($bDEBUG == TRUE) echo '<font color="red">-->'.socket_strerror(socket_last_error($iSocket)).'</font><br>';
			return FALSE;
		}

		return TRUE;
 	}
 
 	private function close()
 	{
		global $iSocket;
		global $bDEBUG;

		@socket_shutdown($iSocket, 2);
		@socket_close($iSocket);
		
		echo("[+]Socket successfully closed.<br>");

		return TRUE;
 	}
 
 	private function receive()
 	{
		global $iSocket;
		global $bDEBUG;
		global $iPROTOCOL;
		global $iBytesToReceive;
		
		$strBuffer = "";
		$strIpClient = "";

		if(!$con = @socket_accept($iSocket))
		{
			echo("[-]Connection failed.<br>");
			if($bDEBUG == TRUE)
			{
				if(socket_strerror(socket_last_error($iSocket)))
				{
					echo '<font color="red">--> Connection timeout.</font><br>';
				}
				else
				{
					echo '<font color="red">-->'.socket_strerror(socket_last_error($iSocket)).'</font><br>';
				}
			} 
			$this->onFailure();
			return FALSE;
		}

		// optional include
		if($iPROTOCOL == SOL_TCP)
		{
			include_once("access_control.php");
			
			$temp = new access_control;
			$temp->acl_logic();
		}

		while(TRUE)
		{
			
			if(!$strBuffer = @socket_read($con , 512, PHP_NORMAL_READ))	// 2. paramater are bytes; 3. parameter: PHP_BINARY_READ
			{
				echo("[-]Could not read from socket.<br>");
				if($bDEBUG == TRUE) echo '<font color="red">-->'.socket_strerror(socket_last_error($iSocket)).'</font><br>';
				$this->onFailure();
				return FALSE;
			}
	
/*			if(-1 == ($iBytes = socket_recvfrom ($iSocket, & $strBuffer, $iBytesToReceive , MSG_WAITALL, & $strIpClient)))
			{
				echo("[-]Could not read from socket.<br>");
				if($bDEBUG == TRUE) echo '<font color="red">-->'.socket_strerror(socket_last_error($iSocket)).'</font><br>';
				$this->onFailure();
				return FALSE;
			}
	
	var_dump($strIpClient);
	
*/


			$strBuffer = trim($strBuffer);
			
			if($strBuffer == "quit")
			{
				echo("[+]Catched the \"quit\" command from <i>".$strIpClient."</i>, quitting.<br>");
				return TRUE;
			}
	
			//write filemgr
			$temp = new filemgr;
			if(!$temp->write($strBuffer))
			{
				echo("[~]Could not write received data to file, but continueing.<br>");
			}
		}
		
		echo("[+]Successfully received data.<br>");
		
		return TRUE;
 	}
 
 	private function listen()
 	{
		global $iPROTOCOL;
		global $iPORT;
		global $iSocket;
		global $strINTERFACE;
		global $bDEBUG;

		if(!@socket_bind($iSocket, null, $iPORT))	// $strINTERFACE
		{
			echo("[-]Could not bind the socket.<br>");
			if($bDEBUG == TRUE) echo '<font color="red">-->'.socket_strerror(socket_last_error($iSocket)).': '.socket_last_error($iSocket).'</font><br>';
			$this->onFailure();

			return FALSE;
		}
		
		if(!@socket_listen($iSocket))
		{
			echo("[-]Could not listen on the socket.<br>");
			if($bDEBUG == TRUE) echo '<font color="red">-->'.socket_strerror(socket_last_error($iSocket)).'</font><br>';
			$this->onFailure();
			return FALSE;
		}

		echo("[+]Now listening on socket.<br>");
		return TRUE;
 	}
 
 	private function chkPortNr()
 	{
		global $iPORT;

		if($iPORT < 1025)
		{
			echo("[-]Port must be over 1024. (Every port below requires root permission!)<br>");
			return FALSE;
		}
		elseif ($iPORT > 65335)
		{
			echo("[-]The port can't be higher then 65335!<br>");
			return FALSE;
		}
		else
		{
			echo("[+]Port ".$iPORT." is allowed to use.<br>");
			return TRUE;
		}
 	}
 } 
 ?>
