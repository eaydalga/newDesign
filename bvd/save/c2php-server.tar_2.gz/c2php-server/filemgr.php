<?php
/*
 * Project:	 	c2php
 * Packet:		c2php-server
 * File:		filemgr.php
 * Created on:	Dec 12, 2007
 * Created by:	pat
 */

 class filemgr
 { 		
 	public function write($strBuffer)
	{
		global $bDEBUG;
		global $strFILENAME;

		if(!@is_writable($this->strGetPath()))
		{
			echo("[-]Log directory not writable.<br>");
			return FALSE;
		}

		$strCompletePath = $this->strGetPath();
		$strCompletePath .= $strFILENAME;

		if(!$fHandle = @fopen($strCompletePath, "a"))
		{
			$temp = error_get_last();
			echo("[-]Could not open log file.<br>");
			if($bDEBUG == TRUE) echo '<font color="red">--> '.$temp["message"].'</font><br>';
			return FALSE;
		}
		
		if(empty($strBuffer))
		{
			$strBuffer = "\n";
		}
		
		$bytes = @fwrite($fHandle, $strBuffer);
		
		if($bytes == FALSE)
		{
			$temp = error_get_last();
			echo("[-]Could not open log file.<br>");
			if($bDEBUG == TRUE) echo '<font color="red">--> '.$temp["message"].'</font><br>';
			return FALSE;
		}
		else
		{
			echo("[+]Wrote ".$bytes." byte(s) to the log file.<br>");
		}
		
		if(!@fclose($fHandle))
		{
			$temp = error_get_last();
			echo("[-]Could not open log file.<br>");
			if($bDEBUG == TRUE) echo '<font color="red">--> '.$temp["message"].'</font><br>';
			return FALSE;	
		}

		return TRUE;
	}
	
	private function strGetPath()
	{
		/* 
		 * ALGO:
		 * whole String: /blah/htdocs/file.php
		 * minus
		 * string end: /file.php
		 * gives
		 * /blah/htdocs (The path to the directory to write the log file)
		 */
		
		$strEND = strrchr(__FILE__, "/");	// returns all chars after the "/" including the "/"; E.g.: "/file.php" 
		
		$strFinal = substr(__FILE__, 0, strlen(__FILE__) - strlen($strEND) + 1); // + 1 to keep the slash at the end
	
		return $strFinal;
	}
 }
?>