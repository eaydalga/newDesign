<?php
/*
 * Project:	 	c2php
 * Packet:		c2php-server
 * File:		access_control.php
 * Created on:	Dec 12, 2007
 * Created by:	pat
 */

 class access_control
 {
	private $arBlackList = array();

	public function acl_logic()
	{

	}

	private function getBlacklist()
	{

	}
 }
?>