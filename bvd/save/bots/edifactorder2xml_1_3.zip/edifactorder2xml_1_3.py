#a distributed plugin is always a zip-file.
#the zip-file requires a index file with the same name, but with extension 'py'.
plugins = [
    {'plugintype':u'channel','idchannel':u'edifactorder2xml.in','type':u'file','inorout':u'in','path':u'botssys/infile/edifactorder2xml','filename':u'*.edi','remove':False},
    {'plugintype':u'channel','idchannel':u'edifactorder2xml.out','inorout':u'out','type':u'file','path':u'botssys/outfile','filename':u'edifactorder2xml.*.xml','charset':u'utf-8'},
    {'plugintype':u'translate','fromeditype':u'edifact','frommessagetype':u'ORDERSD96AUNEAN008','frompartner':u'','topartner':u'','alt':u'edifactorder2xml','active':True,'tscript':u'edifactorder2xml','toeditype':u'xmlnocheck','tomessagetype':u'edifactorder2xml'},
    {'plugintype':u'routes','idroute':u'edifactorder2xml','seq':9999,'fromchannel':u'edifactorder2xml.in','tochannel':u'edifactorder2xml.out','fromeditype':u'edifact','frommessagetype':u'edifact','alt':u'edifactorder2xml'},
    ]
    
        
