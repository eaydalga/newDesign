#mapping-script
import bots.transform as transform
import copy

def main(inn,out):
    out.root = copy.deepcopy(inn.root)
