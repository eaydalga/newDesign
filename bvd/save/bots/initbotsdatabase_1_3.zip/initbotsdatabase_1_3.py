#a distributed plugin is always a zip-file.
plugins = [
    {'plugintype':u'mutex','mutexk':0,'mutexer':0},
    {'plugintype':u'channel','idchannel':u'botsreport','type':u'smtp','inorout':u'out','host':u'your.host.com','port':25,'username':u'username@your.host.com','secret':u'secret'},
    {'plugintype':u'partner','idpartner':u'botsreportsender','name':u'botsreportsender','active':True},
    {'plugintype':u'partner','idpartner':u'botsreportreceiver','name':u'botsreportreceiver','active':True},
    {'plugintype':u'chanpar','idpartner':u'botsreportsender','mail':u'bots@your.host.com','fromorto':u'from','idchannel':u'botsreport'},
    {'plugintype':u'chanpar','idpartner':u'botsreportreceiver','mail':u'you@your.host.com','fromorto':u'to','idchannel':u'botsreport'},
    ]

