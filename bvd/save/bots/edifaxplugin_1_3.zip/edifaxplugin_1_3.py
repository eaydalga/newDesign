#a distributed plugin is always a zip-file.
#this zip-file requires a index file, same name as plugin (but extension 'py').
plugins = [
    {'plugintype':u'channel','idchannel':u'edifaxordersin','type':u'file','inorout':u'in',
        'path':u'botssys/infile/03print','filename':u'orders2prt*.edi','remove':False},
    {'plugintype':u'channel','idchannel':u'edifaxordersout','inorout':u'out',
            'type':u'file','path':u'botssys/outfile','filename':u'edifaxorders*.html','charset':u'utf-8'},
    {'plugintype':u'translate','fromeditype':u'edifact','frommessagetype':u'ORDERSD96AUNEAN008','frompartner':u'','topartner':u'',
        'alt':u'edifaxorders','active':True,'tscript':u'edifaxorders','toeditype':u'template', 'tomessagetype':u'orders2print'},
    {'plugintype':u'routes','idroute':u'edifax','seq':9999,'fromchannel':u'edifaxordersin',
        'tochannel':u'edifaxordersout','fromeditype':u'edifact','frommessagetype':u'edifact','alt':u'edifaxorders'},
    ]
    
        
