codeconversions = {
'351':'AAK',
'35E':'AAK',
'220':'ON',
'224':'ON',
'50E':'ON',
'83':'IV',
'380':'IV',
'384':'IV',
}
