plugins = [
    {'plugintype':u'routes','idroute':u'myfirstroute','seq':9999,'fromchannel':u'myfirstroute_in','tochannel':u'myfirstroute_out','fromeditype':u'edifact','frommessagetype':u'edifact','toeditype':u'fixed'},
    {'plugintype':u'channel','idchannel':u'myfirstroute_in', 'type':u'file','inorout':u'in', 'path':u'botssys/infile/myfirstroute_in', 'filename':u'*.edi','remove':False},
    {'plugintype':u'channel','idchannel':u'myfirstroute_out','type':u'file','inorout':u'out','path':u'botssys/outfile','filename':u'ordersfixedout*.inh','charset':u'iso-8859-1'},
    {'plugintype':u'translate','fromeditype':u'edifact','frommessagetype':u'ORDERSD96AUNEAN008','active':True,'alt':u'','topartner':u'','frompartner':u'','tscript':u'myfirstscriptordersedi2fixed','toeditype':u'fixed',  'tomessagetype':u'ordersfixed'},
    ]
