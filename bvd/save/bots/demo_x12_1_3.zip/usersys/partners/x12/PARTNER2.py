
syntax = { 
        'field_sep'  : ')',
        'version'    :  '00401',
        }
