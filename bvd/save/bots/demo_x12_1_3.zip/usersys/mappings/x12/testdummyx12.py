#mapping-script

def main(inn,out):
    print 'in testdummyx12.py'
    out.put({'BOTSID':'HEA','ORDERNUMMER':'1234567890'})

    #~ for lin in inn.getloop({'BOTSID':'UNH'},{'BOTSID':'LIN'}):
        #~ lou = out.putloop({'BOTSID':'HEA'},{'BOTSID':'LIN'})
        #~ lou.put({'BOTSID':'LIN','REGEL':lin.get({'BOTSID':'LIN','1082':None})})
        #~ lou.put({'BOTSID':'LIN','ARTIKEL':lin.get({'BOTSID':'LIN','C212.7140':None})})
        #~ lou.put({'BOTSID':'LIN','BESTELDAANTAL':lin.get({'BOTSID':'LIN'},{'BOTSID':'QTY','C186.6063':'21','C186.6060':None})})
        #~ lou.put({'BOTSID':'LIN','PROMOTIECODE':lin.get({'BOTSID':'LIN'},{'BOTSID':'RFF','C506.1153':'PD','C506.1154':None})})
        #~ lou.put({'BOTSID':'LIN','ARTIKELOMSCHRIJVING':lin.get({'BOTSID':'LIN'},{'BOTSID':'IMD','C960.4294':None})})
